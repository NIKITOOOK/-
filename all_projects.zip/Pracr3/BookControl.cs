﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pracr3
{
    public partial class BookControl : UserControl
    {
        Book currentBook;
        public BookControl(Book book)
        {
            InitializeComponent();

            currentBook = book;

            LoadBookDataToControls();
        }

        private void LoadBookDataToControls()
        {
            TitleLabel.Text = currentBook.Author + " " + currentBook.Title + " (" + currentBook.Year + ")";
            DescriptionLabel.Text = currentBook.Description;
            CoverPictureBox.BackgroundImage = currentBook.Cover;
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            BookForm editBoolForm = new BookForm(currentBook);
            if (editBoolForm.ShowDialog() == DialogResult.OK)
            {
                LoadBookDataToControls();
            }
        }

        public BookControl()
        {
            InitializeComponent();

            currentBook = new Book() { Author = "Автор", Title = "Название", Year = 1999, Description = "Описание" };

            LoadBookDataToControls();
        }
    }
}