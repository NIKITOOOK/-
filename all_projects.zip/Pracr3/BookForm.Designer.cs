﻿namespace Pracr3
{
    partial class BookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            SaveButton = new Button();
            AuthorTextBox = new TextBox();
            TitleTextBox = new TextBox();
            YearTextBox = new TextBox();
            DescriptionTextBox = new TextBox();
            CoverPictureBox = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)CoverPictureBox).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 37);
            label1.Name = "label1";
            label1.Size = new Size(51, 20);
            label1.TabIndex = 0;
            label1.Text = "Автор";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 102);
            label2.Name = "label2";
            label2.Size = new Size(77, 20);
            label2.TabIndex = 1;
            label2.Text = "Название";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 167);
            label3.Name = "label3";
            label3.Size = new Size(95, 20);
            label3.TabIndex = 2;
            label3.Text = "Год издания";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 232);
            label4.Name = "label4";
            label4.Size = new Size(79, 20);
            label4.TabIndex = 3;
            label4.Text = "Описание";
            // 
            // SaveButton
            // 
            SaveButton.Location = new Point(498, 364);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(267, 29);
            SaveButton.TabIndex = 4;
            SaveButton.Text = "Сохранить";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // AuthorTextBox
            // 
            AuthorTextBox.Location = new Point(12, 66);
            AuthorTextBox.Name = "AuthorTextBox";
            AuthorTextBox.Size = new Size(449, 27);
            AuthorTextBox.TabIndex = 5;
            // 
            // TitleTextBox
            // 
            TitleTextBox.Location = new Point(12, 131);
            TitleTextBox.Name = "TitleTextBox";
            TitleTextBox.Size = new Size(449, 27);
            TitleTextBox.TabIndex = 6;
            // 
            // YearTextBox
            // 
            YearTextBox.Location = new Point(12, 196);
            YearTextBox.Name = "YearTextBox";
            YearTextBox.Size = new Size(449, 27);
            YearTextBox.TabIndex = 7;
            // 
            // DescriptionTextBox
            // 
            DescriptionTextBox.Location = new Point(12, 261);
            DescriptionTextBox.Multiline = true;
            DescriptionTextBox.Name = "DescriptionTextBox";
            DescriptionTextBox.Size = new Size(449, 177);
            DescriptionTextBox.TabIndex = 8;
            // 
            // CoverPictureBox
            // 
            CoverPictureBox.BackgroundImageLayout = ImageLayout.Zoom;
            CoverPictureBox.BorderStyle = BorderStyle.Fixed3D;
            CoverPictureBox.Location = new Point(498, 42);
            CoverPictureBox.Name = "CoverPictureBox";
            CoverPictureBox.Size = new Size(267, 316);
            CoverPictureBox.TabIndex = 9;
            CoverPictureBox.TabStop = false;
            CoverPictureBox.Click += CoverPictureBox_Click;
            // 
            // BookForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(CoverPictureBox);
            Controls.Add(DescriptionTextBox);
            Controls.Add(YearTextBox);
            Controls.Add(TitleTextBox);
            Controls.Add(AuthorTextBox);
            Controls.Add(SaveButton);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "BookForm";
            Text = "Информация о книге";
            ((System.ComponentModel.ISupportInitialize)CoverPictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button SaveButton;
        private TextBox AuthorTextBox;
        private TextBox TitleTextBox;
        private TextBox YearTextBox;
        private TextBox DescriptionTextBox;
        private PictureBox CoverPictureBox;
    }
}