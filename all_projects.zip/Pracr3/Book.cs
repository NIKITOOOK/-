﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Pracr3
{
    public class Book
    {
        /// <summary>
        /// Имя автора
        /// </summary>
        public string Author { get; set; }

        /// <summary>
        /// Название книги
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Год издания
        /// </summary>
        public int Year { get; set; }

        /// <summary>
        /// Описание книги
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Картинка обложки
        /// </summary>
        [JsonIgnore]
        public Image Cover { get; set; }
    }
}