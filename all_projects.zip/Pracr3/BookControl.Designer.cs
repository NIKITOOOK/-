﻿namespace Pracr3
{
    partial class BookControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            CoverPictureBox = new PictureBox();
            TitleLabel = new Label();
            EditButton = new Button();
            DescriptionLabel = new Label();
            ((System.ComponentModel.ISupportInitialize)CoverPictureBox).BeginInit();
            SuspendLayout();
            // 
            // CoverPictureBox
            // 
            CoverPictureBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            CoverPictureBox.BackgroundImageLayout = ImageLayout.Zoom;
            CoverPictureBox.BorderStyle = BorderStyle.Fixed3D;
            CoverPictureBox.Location = new Point(14, 13);
            CoverPictureBox.Name = "CoverPictureBox";
            CoverPictureBox.Size = new Size(183, 195);
            CoverPictureBox.TabIndex = 0;
            CoverPictureBox.TabStop = false;
            // 
            // TitleLabel
            // 
            TitleLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            TitleLabel.Location = new Point(225, 21);
            TitleLabel.Name = "TitleLabel";
            TitleLabel.Size = new Size(619, 37);
            TitleLabel.TabIndex = 1;
            TitleLabel.Text = "Автор.Название (год издания)";
            // 
            // EditButton
            // 
            EditButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            EditButton.Location = new Point(875, 21);
            EditButton.Name = "EditButton";
            EditButton.Size = new Size(43, 37);
            EditButton.TabIndex = 2;
            EditButton.Text = "✎";
            EditButton.UseVisualStyleBackColor = true;
            EditButton.Click += EditButton_Click;
            // 
            // DescriptionLabel
            // 
            DescriptionLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            DescriptionLabel.Location = new Point(225, 74);
            DescriptionLabel.Name = "DescriptionLabel";
            DescriptionLabel.Size = new Size(693, 153);
            DescriptionLabel.TabIndex = 3;
            DescriptionLabel.Text = "описание";
            // 
            // BookControl
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BorderStyle = BorderStyle.Fixed3D;
            Controls.Add(DescriptionLabel);
            Controls.Add(EditButton);
            Controls.Add(TitleLabel);
            Controls.Add(CoverPictureBox);
            Name = "BookControl";
            Size = new Size(942, 216);
            ((System.ComponentModel.ISupportInitialize)CoverPictureBox).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox CoverPictureBox;
        private Label TitleLabel;
        private Button EditButton;
        private Label DescriptionLabel;
    }
}
