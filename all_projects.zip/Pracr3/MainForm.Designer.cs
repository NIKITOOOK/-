﻿namespace Pracr3
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BooksListTableLayout = new TableLayoutPanel();
            SuspendLayout();
            // 
            // BooksListTableLayout
            // 
            BooksListTableLayout.AutoScroll = true;
            BooksListTableLayout.BackgroundImageLayout = ImageLayout.None;
            BooksListTableLayout.ColumnCount = 1;
            BooksListTableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            BooksListTableLayout.Dock = DockStyle.Fill;
            BooksListTableLayout.Location = new Point(0, 0);
            BooksListTableLayout.Name = "BooksListTableLayout";
            BooksListTableLayout.RowCount = 1;
            BooksListTableLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 300F));
            BooksListTableLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            BooksListTableLayout.Size = new Size(1025, 682);
            BooksListTableLayout.TabIndex = 1;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1025, 682);
            Controls.Add(BooksListTableLayout);
            Name = "MainForm";
            Text = "Книги на легкое чтение";
            FormClosed += MainForm_FormClosed;
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel BooksListTableLayout;
    }
}
