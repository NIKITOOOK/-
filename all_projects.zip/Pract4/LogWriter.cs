using System;
using System.IO;
using System.Text;

namespace Pract4
{
    class LogWriter
    {
        // Снаружи можно задать путь к файлу, но прочитать его снаружи нельзя.
        public string LogPath { private get; set; }

        // Метод Write подписывается на событие: student.Changed += logWriter.Write;
        // Вызывается автоматически при каждом срабатывании события Changed.
        public void Write(IStudentReader student, int changedTaskCount)
        {
            if (string.IsNullOrWhiteSpace(LogPath))
            {
                return;
            }

            string status = changedTaskCount > 0 ? "принято" : "отозвано";

            string line =
                $"{DateTime.Now};{student.Name};{status};" +
                $"{Math.Abs(changedTaskCount)};{student.ProgressProcent:F2}%";

            File.AppendAllText(LogPath, line + Environment.NewLine, Encoding.UTF8);
        }
    }
}
