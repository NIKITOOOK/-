using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract4
{
//интерфейс - наряду с классы/структуры, ссылочный тип, определяет функционал набор методов и свойств без реализации,
//которые обязуются реал классы/структры которые наследуют интерфейс
    interface IStudentReader
    {

        string Name { get; }


        double ProgressProcent { get; }
    }
}
