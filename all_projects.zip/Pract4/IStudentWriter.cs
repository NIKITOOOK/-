using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract4
{
    interface IStudentWriter
    {
        int NewDoneTaskCount { set; }
    }
}
