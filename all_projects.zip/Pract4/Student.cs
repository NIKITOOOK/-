using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract4
{
    class Student : IStudentReader, IStudentWriter//два интерфейса
    {
        private int planTaskCount; // данные хранятся внутри класса и недоступны снаружи напрямую
        private int doneTaskCount;

        // Свойство — специальная конструкция C# для управляемого доступа к данным класса.
        // При чтении вызывается get, при присваивании — set, реализует инкапсуляцию: данные не открыты напрямую, доступ контролируется

        // get открыт (public) — имя студента можно прочитать из любого места.
        // set закрыт (private) — изменить имя можно только внутри самого класса.
        public string Name { get; private set; }

        public delegate void ChangedEventHandler(IStudentReader student, int changedTaskCount);


        public event ChangedEventHandler Changed;

        public Student(string name, int planTaskCount, int doneTaskCount)
        {
            Name = name;
            this.planTaskCount = planTaskCount;
            this.doneTaskCount = doneTaskCount;
        }
        public double ProgressProcent
        {
            get
            {
                return doneTaskCount * 100.0 / planTaskCount;
            }
        }

        public int NewDoneTaskCount
        {
            set
            {
                doneTaskCount += value;

                // Если изменение ненулевое — вызвать событие Changed
                // Оператор ?. (null-conditional) защищает от вызова, если подписчиков нет
                // Invoke передает всем подписчикам: ссылку на студента и число измененных работ
                if (value != 0)
                {
                    Changed?.Invoke(this, value);
                }
            }
        }
    }
}
