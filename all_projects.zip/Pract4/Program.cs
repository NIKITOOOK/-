using System;

namespace Pract4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // объект Student
            Student student = new Student("Иванов Иван Иванович", 10, 1);//имя, план (10 работ), уже выполнено (1 работа)

            ConsoleWriter consoleWriter = new ConsoleWriter();
            LogWriter logWriter = new LogWriter();
            logWriter.LogPath = "log.csv";

            // Подписка на Changed "+="
            student.Changed += consoleWriter.Write;
            student.Changed += logWriter.Write;

            AddTasks(student);

            // Отписка consoleWriter "-="
            student.Changed -= consoleWriter.Write;

            RemoveTasks(student);

            Console.ReadKey();
        }

        // Принимает студента через IStudentWriter — может только изменять данные,
        // читать имя или прогресс через этот интерфейс невозможно
        static void AddTasks(IStudentWriter studentWriter)
        {
            // Каждое присваивание вызывает set свойства NewDoneTaskCount,
            // который прибавляет значение к doneTaskCount и вызывает событие Changed
            studentWriter.NewDoneTaskCount = 2;
            studentWriter.NewDoneTaskCount = 1;
            studentWriter.NewDoneTaskCount = 5;
        }

        // Отрицательное значение — отзыв выполненных работ
        static void RemoveTasks(IStudentWriter studentWriter)
        {
            studentWriter.NewDoneTaskCount = -2;
            studentWriter.NewDoneTaskCount = -1;
        }
    }
}
