using System;

namespace Pract4
{

    class ConsoleWriter
    {

        public void Write(IStudentReader student, int changedTaskCount)
        {
            string status = changedTaskCount > 0 ? "принято" : "отозвано";

            Console.WriteLine(
                $"{DateTime.Now}; студент: {student.Name}; " +
                $"{status}: {Math.Abs(changedTaskCount)}; " +
                $"прогресс: {student.ProgressProcent:F2}%");
        }
    }
}
