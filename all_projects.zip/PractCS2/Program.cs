﻿using System;

namespace PractCS2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var filePath = "data.txt";
                var parser = new FileLinesParser(in filePath, out var linesCount);
                Console.WriteLine("Количество считанных строк: " + linesCount);
                parser.AddNewLines(
                    "Кузнецов*Андрей*22",
                    "Смирнова*Анна*20"
                );
                parser.SplitLines();
                parser.SetExtraProcessor((ref string[][] table) =>
                {
                    foreach (var line in table)
                    {
                        for (var i = 0; i < line.Length; i++)
                        {
                            line[i] = line[i].ToLower();
                        }
                    }
                });
                parser.Save();
                Console.WriteLine("Файл обработан.");
                Console.WriteLine("Создана копия исходного файла data.txt.old.");
                Console.WriteLine("Результат сохранен в data.txt.");
            }
            catch (Exception exception)
            {
                Console.WriteLine("Ошибка: " + exception.Message);
            }
            Console.ReadKey();
        }
    }
}