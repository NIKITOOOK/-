﻿using System;
using System.IO;

namespace PractCS2
{
    internal class FileLinesParser
    {
        private string FilePath;
        private string[] SourceLines;
        private string[][] Table;
        public delegate void ExtraProcessor(ref string[][] table);
        private ExtraProcessor extraProcessor;
        public FileLinesParser(in string filePath, out int linesCount)
        {
            if (!File.Exists(filePath))
            {
                throw new ArgumentException("Файл по заданному пути не существует");
            }

            FilePath = filePath;
            SourceLines = File.ReadAllLines(filePath);
            linesCount = SourceLines.Length;
        }

        public void SplitLines(in char splitter = '*')
        {
            Table = new string[SourceLines.Length][];
            var index = 0;
            foreach (var line in SourceLines)
            {
                Table[index] = line.Split(splitter);
                index++;
            }
        }

        public void AddNewLines(params string[] newLines)
        {
            if (newLines.Length == 0)
            {
                return;
            }
            var newSize = SourceLines.Length + newLines.Length;
            var bufferLines = new string[newSize];
            for (var i = 0; i < SourceLines.Length; i++)
            {
                bufferLines[i] = SourceLines[i];
            }
            for (var i = 0; i < newLines.Length; i++)
            {
                bufferLines[SourceLines.Length + i] = newLines[i];
            }
            SourceLines = bufferLines;
        }
        public void SetExtraProcessor(ExtraProcessor processor)
        {
            extraProcessor = processor;
        }
        public void Save()
        {
            if (extraProcessor == null)
            {
                throw new ArgumentException("Не задан метод дополнительной обработки строк");
            }
            File.Copy(FilePath, FilePath + ".old", true);
            SplitLines();
            extraProcessor(ref Table);

            using (var fileStream = File.Create(FilePath))
            {
                var writer = new StreamWriter(fileStream);

                foreach (var line in Table)
                {
                    foreach (var cell in line)
                    {
                        writer.Write(cell);
                        writer.Write(";");
                    }
                    writer.Write("\r\n");
                }
                writer.Close();
            }
        }
    }
}