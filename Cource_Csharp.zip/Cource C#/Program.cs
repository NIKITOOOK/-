﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Cource_C_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            JournalPost journalPost = new JournalPost(
                @"\path\path\path",
                DateTime.Now,
                10,
                10.05448984944999,
                "Специальный знак $ идентифицирует строковый литерал как интерполированную строку. "
            );

            ThematicJournalPost newsPost = new ThematicJournalPost(
                @"\path\path\path",
                DateTime.Now,
                10,
                10.05448984944999,
                "Специальный знак $ идентифицирует строковый литерал как интерполированную строку. ",
                ThematicJournalPost.CategotyType.News
            );

            ReviewedJournalPost reviewedPost = new ReviewedJournalPost(
                @"\path\path\path",
                DateTime.Now,
                10,
                10.05448984944999,
                "Специальный знак $ идентифицирует строковый литерал как интерполированную строку. ",
                "Хороший пост."
            );

            System.Console.WriteLine(journalPost);
            System.Console.WriteLine(newsPost);
            System.Console.WriteLine(reviewedPost);

            System.Console.Read();
        }
    }
}