﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;   

namespace Cource_C_
{
    internal class ReviewedJournalPost : JournalPost
    {
        public string Review = null;

        public ReviewedJournalPost(
                string path,
                DateTime creationDateTime,
                int viewCount,
                double rating,
                String text,
                string review) : base(
                        path,
                        creationDateTime,
                        viewCount,
                        rating,
                        text
                    )
        {
            Review = review;
        }

        public override void Print()
        {
            base.Print();
            System.Console.Out.WriteLine($"Рецензия: {Review}");
        }

        public override string ToString()
        {
            return base.ToString() + $"\r\nРецензия: {Review}";
        }
    }
}