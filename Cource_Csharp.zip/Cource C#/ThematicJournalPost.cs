﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;   

namespace Cource_C_
{
    internal class ThematicJournalPost : JournalPost
    {
        public enum CategotyType { None, News = 10, Info }
        public CategotyType Category = CategotyType.None;

        public ThematicJournalPost(
                string path,
                DateTime creationDateTime,
                int viewCount,
                double rating,
                String text,
                CategotyType category) : base(
                        path,
                        creationDateTime,
                        viewCount,
                        rating,
                        text
                    )
        {
            Category = category;
        }

        public override void Print()
        {
            base.Print();
            System.Console.Out.WriteLine($"Категория: {Category}");
        }

        public override string ToString()
        {
            return base.ToString() + $"\r\nКатегория: {Category}";
        }
    }
}