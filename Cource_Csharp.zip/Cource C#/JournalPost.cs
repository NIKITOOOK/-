﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Cource_C_
{
    internal class JournalPost
    {
        public string Path = null;
        public DateTime? CreationDateTime = null;
        public int ViewCount = 0;
        public double Rating = 0.0;
        public String Text = null;

        public JournalPost(string path,
                DateTime creationDateTime,
                int viewCount,
                double rating,
                String text)
        {
            Path = path;
            CreationDateTime = creationDateTime;
            ViewCount = viewCount;
            Rating = rating;
            Text = text;
        }

        public virtual void Print()
        {
            System.Console.Out.WriteLine(
                $"Путь до поста {Path}. Дата поста: {CreationDateTime}.\r\n" +
                $"Количество просмотров: {ViewCount}. Рейтинг: {Rating:F3}.\r\n" +
                Text
            );
        }

        public override string ToString()
        {
            return $"Путь до поста {Path}. Дата поста: {CreationDateTime}.\r\n" +
                   $"Количество просмотров: {ViewCount}. Рейтинг: {Rating:F3}.\r\n" +
                   Text;
        }
    }
}